﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.IO;

using SpeechLib;//导入语音
using System.Threading;

namespace bdapi
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class Form1 : Form
    {
        
        string indata;
        string outdata;
        string distanced; //前方站距离
        string czmc;
        public static double Longitude = 116.404;//初始化经度
        public static double Latitude = 39.915; //初始化纬度
        

        public Form1()
        {
            InitializeComponent();

            webBrowser1.ScriptErrorsSuppressed = true;
            string path = Path.Combine(Application.StartupPath, "HTMLPage1.html");
            webBrowser1.Navigate(path);
            webBrowser1.ObjectForScripting = this;//设置对象为当前BusinessDataExportFigure窗体

            
        }
        
        
        
        
        private void Form1_Load(object sender, EventArgs e)
        {


            if (this.serialPort1.IsOpen && this.serialPort2.IsOpen)
            {
                this.label9.Text = "两端口都已打开";
            }
            else if (this.serialPort1.IsOpen && !this.serialPort2.IsOpen)
            {
                this.label9.Text = "COM4端口已打开 COM5端口已关闭";
            }
            else if (!this.serialPort1.IsOpen && this.serialPort2.IsOpen)
            {
                this.label9.Text = "COM4端口已关闭 COM5端口已打开";
            }
            else
            {
                this.label9.Text = "两端口都已关闭";
            }

        }
       

        

        /// <summary>
        /// 启动gps
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.serialPort1.IsOpen) { 
                   this.serialPort1.DataBits = 8;
                this.serialPort1.BaudRate = 9600;
                this.serialPort1.PortName = "COM4";
                this.serialPort1.StopBits = System.IO.Ports.StopBits.One;
                this.serialPort1.Parity = System.IO.Ports.Parity.None;
                this.serialPort1.Encoding = System.Text.Encoding.UTF8;
                serialPort1.Open();
                }
                if (!this.serialPort2.IsOpen)
                {
                    this.serialPort2.DataBits = 8;
                    this.serialPort2.BaudRate = 9600;
                    this.serialPort2.PortName = "COM5";
                    this.serialPort2.StopBits = System.IO.Ports.StopBits.One;
                    this.serialPort2.Parity = System.IO.Ports.Parity.None;
                    this.serialPort2.Encoding = System.Text.Encoding.UTF8;
                    serialPort2.Open();
                }



                string outdata1 = "AT+QGPSCFG='gpsnmeatype',1\r\n";
                string outdata2 = "AT+QGPSCFG='nmeasrc',1\r\n";
                string outdata3 = "AT+QGPS=1\r\n";

                serialPort2.Write(outdata1);//把字符串写入端口
                serialPort2.Write(outdata2);
                serialPort2.Write(outdata3);

                if (this.serialPort1.IsOpen && this.serialPort2.IsOpen)
                {
                    this.label9.Text = "两端口都已打开";
                }
                else if (this.serialPort1.IsOpen && !this.serialPort2.IsOpen)
                {
                    this.label9.Text = "COM4端口已打开 COM5端口已关闭";
                }
                else if (!this.serialPort1.IsOpen && this.serialPort2.IsOpen)
                {
                    this.label9.Text = "COM4端口已关闭 COM5端口已打开";
                }
                else
                {
                    this.label9.Text = "两端口都已关闭";
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.ToString()); }
        }
        /// <summary>
        /// 关闭gps
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string outdata4 = "AT+QGPSEND \r\n";
                serialPort2.Write(outdata4);
                this.label7.Text = "无数据";
                this.label2.Text = "无数据";
                this.label3.Text = "无数据";
                this.label11.Text = "无数据";
                this.label15.Text = "无数据";

            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }


        /// <summary>
        /// 接受到数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {               
                indata = serialPort1.ReadExisting();
                this.Invoke(new EventHandler(DisplayText));
                string outdata5 = "AT+QGPSLOC?\r\n";
                serialPort2.Write(outdata5);
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
            

        }

        private void DisplayText(object sender, EventArgs e)
        {
            
            string[] jwds = indata.Split(',');
            if (jwds[0] == "$GPGGA" && jwds[2] != "")

               
            {
                //经度转换
                string[] longitudeY = (double.Parse(jwds[2])/100).ToString().Split('.');
                string du = longitudeY[0];
                string fen = (double.Parse(jwds[2]) - double.Parse(du) * 100).ToString();
                Latitude = double.Parse(fen) / 60 + double.Parse(du);
                //纬度转换
                string[] latitudeY = (double.Parse(jwds[4])/100).ToString().Split('.');
                string du1 = latitudeY[0];
                string fen1 = (double.Parse(jwds[4]) - double.Parse(du1) * 100).ToString();
                Longitude = double.Parse(fen1) / 60 + double.Parse(du1);

                Distance distance = new Distance();
                this.label11.Text = float.Parse(distance.LantitudeLongitudeDist(float.Parse(Longitude.ToString()),float.Parse(Latitude.ToString()), 114.478187,38.009778).ToString()).ToString()+"Km";//到前方到站的距离
                distanced = float.Parse(distance.LantitudeLongitudeDist(float.Parse(Longitude.ToString()), float.Parse(Latitude.ToString()), 114.478187, 38.009778).ToString()).ToString();
                this.label7.Text = Latitude.ToString()+"N";
                this.label2.Text = Longitude.ToString()+"E";
                
                
                string ccconn = " select * from " + czmc;
                DB db = new DB();
                DataTable dt = db.reDt(ccconn);
                int num = dt.Rows.Count;//有多少条数据
                string czjd = "";
                string czwd = "";
                

                double [] zzdistance =  new double [num] ;
                
                for (int i = 0; i <num;i++ )
                {
                   czjd = dt.Rows[i][2].ToString();
                   czwd = dt.Rows[i][3].ToString();

                   zzdistance[i] = distance.LantitudeLongitudeDist(float.Parse(czjd),float.Parse(czwd), Longitude, Latitude);//判断当前点与每个车站的距离
                }

                double minnum = zzdistance[0];
                    int minid = 0;
                    for (int n = 0; n < zzdistance.Length; n++)
                    {
                        if (zzdistance[n] < minnum)
                        {
                            minnum = zzdistance[n];
                            minid = n;
                       
                        }
                    }

                this.label19.Text = zzdistance[minid].ToString();//最短距离
                int id = minid + 1;

                
                if ((num - 1) >= id && (minid - 1) >= 0)//前后站都有
                {
                    string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,前一站，后一站) values('" + Longitude.ToString() + "' ,'" + Latitude.ToString() + "','" + this.label3.Text.ToString() + "','" + dt.Rows[minid][1].ToString() + "','" + zzdistance[minid].ToString() + "','" + dt.Rows[minid - 1][1].ToString()+ "','" + dt.Rows[minid+1][1].ToString() + "')";
                    db.sqlEx(log);
                    
                }
                else if ((num - 1) >= id && (minid - 1)<0)//无前一站
                {

                    string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,后一站) values('" + Longitude.ToString() + "' ,'" + Latitude.ToString() + "','" + this.label3.Text.ToString() + "','" + dt.Rows[minid][1].ToString() + "','" + zzdistance[minid].ToString() + "','" + dt.Rows[minid+1][1].ToString() + "')";
                    db.sqlEx(log);
                    
                }
                else if ((num - 1)<id && (minid - 1) >= 0)//无后一站
                {
                    string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,前一站) values('" + Longitude.ToString() + "' ,'" + Latitude.ToString() + "','" + this.label3.Text.ToString() + "','" + dt.Rows[minid][1].ToString() + "','" + zzdistance[minid].ToString() + "','" + dt.Rows[minid - 1][1].ToString() + "')";
                    db.sqlEx(log);   
                }
            }



        }
        public string GetLongitude()
        {
            //供页面调用以传递数据
            return Longitude.ToString();
        }
        public string GetLatitude()
        {
            //供页面调用以传递数据
            return Latitude.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Refresh();
        }

        private void serialPort2_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try {
                outdata = serialPort2.ReadExisting();

                this.Invoke(new EventHandler(DisplayText1));
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            


        }
        private void DisplayText1(object sender, EventArgs e)
        {
          
            string[] spkm = outdata.Split(',');
            if (spkm.Length >7)
            {
                if (this.distanced != "" && float.Parse(spkm[7]) > 0)
                {

                    this.label15.Text = (float.Parse(distanced) / float.Parse(spkm[7])).ToString();
                }
                else
                {
                    this.label15.Text = "--";

                }
                this.label3.Text = spkm[7].ToString()+"km/h";

            }
            
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("你是否确认安装微软中文男声语音库5.1?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                System.Diagnostics.Process.Start(Application.StartupPath + "\\spchapi.exe");
                try
                {
                    System.Diagnostics.Process.Start(Application.StartupPath + "\\Microsoft_TTS_51_chs.msi");
                }
                catch
                {
                    MessageBox.Show("请检查操作系统中是否存在Windews Installer(MSI格式)安装程序支持文件。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                return;
            }
        }

        /// <summary>
        /// 选择车次
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click_1(object sender, EventArgs e)
        {
            if (this.comboBox1.Text != "")
            {
                this.comboBox1.Enabled = false;
                czmc = this.comboBox1.Text;
            }
            else
            {
                MessageBox.Show("请先选择车次！");
            }
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.comboBox1.Enabled = true;
            this.comboBox1.Text = "";
            
        }
    }
}
