﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.IO;

using SpeechLib;//导入语音
using System.Threading;

namespace bdapi
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class Form1 : Form
    {
        
        string indata;
        string outdata;
        string distanced; //前方站距离
        string trainNumber;//车次名称
        public static double Longitude = 116.404;//初始化经度
        public static double Latitude = 39.915; //初始化纬度
        

        public Form1()
        {
            InitializeComponent();

            webBrowser1.ScriptErrorsSuppressed = true;
            string path = Path.Combine(Application.StartupPath, "HTMLPage1.html");
            webBrowser1.Navigate(path);
            webBrowser1.ObjectForScripting = this;//设置对象为当前BusinessDataExportFigure窗体

            
        }
        
        
        
        
        private void Form1_Load(object sender, EventArgs e)
        {
            

            if (this.serialPort1.IsOpen && this.serialPort2.IsOpen)
            {
                this.label9.Text = "两端口都已打开";
            }
            else if (this.serialPort1.IsOpen && !this.serialPort2.IsOpen)
            {
                this.label9.Text = "COM4端口已打开 COM5端口已关闭";
            }
            else if (!this.serialPort1.IsOpen && this.serialPort2.IsOpen)
            {
                this.label9.Text = "COM4端口已关闭 COM5端口已打开";
            }
            else
            {
                this.label9.Text = "两端口都已关闭";
            }

        }
       

        

        /// <summary>
        /// 启动gps
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.serialPort1.IsOpen) { 
                   this.serialPort1.DataBits = 8;
                this.serialPort1.BaudRate = 9600;
                this.serialPort1.PortName = "COM4";
                this.serialPort1.StopBits = System.IO.Ports.StopBits.One;
                this.serialPort1.Parity = System.IO.Ports.Parity.None;
                this.serialPort1.Encoding = System.Text.Encoding.UTF8;
                serialPort1.Open();
                }
                if (!this.serialPort2.IsOpen)
                {
                    this.serialPort2.DataBits = 8;
                    this.serialPort2.BaudRate = 9600;
                    this.serialPort2.PortName = "COM5";
                    this.serialPort2.StopBits = System.IO.Ports.StopBits.One;
                    this.serialPort2.Parity = System.IO.Ports.Parity.None;
                    this.serialPort2.Encoding = System.Text.Encoding.UTF8;
                    serialPort2.Open();
                }



                string outdata1 = "AT+QGPSCFG='gpsnmeatype',1\r\n";
                string outdata2 = "AT+QGPSCFG='nmeasrc',1\r\n";
                string outdata3 = "AT+QGPS=1\r\n";

                serialPort2.Write(outdata1);//把字符串写入端口
                serialPort2.Write(outdata2);
                serialPort2.Write(outdata3);

                if (this.serialPort1.IsOpen && this.serialPort2.IsOpen)
                {
                    this.label9.Text = "两端口都已打开";
                }
                else if (this.serialPort1.IsOpen && !this.serialPort2.IsOpen)
                {
                    this.label9.Text = "COM4端口已打开 COM5端口已关闭";
                }
                else if (!this.serialPort1.IsOpen && this.serialPort2.IsOpen)
                {
                    this.label9.Text = "COM4端口已关闭 COM5端口已打开";
                }
                else
                {
                    this.label9.Text = "两端口都已关闭";
                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.ToString()); }
        }
        /// <summary>
        /// 关闭gps
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string outdata4 = "AT+QGPSEND \r\n";
                serialPort2.Write(outdata4);
                this.label7.Text = "无数据";
                this.label2.Text = "无数据";
                this.label3.Text = "无数据";
                this.label11.Text = "无数据";
                this.label15.Text = "无数据";

            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }


        /// <summary>
        /// 接受到数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {               
                indata = serialPort1.ReadExisting();
                this.Invoke(new EventHandler(DisplayText));
                string outdata5 = "AT+QGPSLOC?\r\n";
                serialPort2.Write(outdata5);
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
            

        }

        public bool beyondDistance = true;//是否执行报站的第一个关键数据；
        public bool withinDistance = true;//是否执行报站的第二个关键数据；
        public bool outDistance = true;//是否执行报站的第二个关键数据；

        private void DisplayText(object sender, EventArgs e)
        {
            try {
                this.label3.Text = speednow ;
                string[] longitudeLatitude = indata.Split(',');
                if (longitudeLatitude[0] == "$GPGGA" && longitudeLatitude[2] != "")


                {
                    //经度转换
                    string[] longitudeY = (double.Parse(longitudeLatitude[2]) / 100).ToString().Split('.');
                    string du = longitudeY[0];
                    string fen = (double.Parse(longitudeLatitude[2]) - double.Parse(du) * 100).ToString();
                    Latitude = double.Parse(fen) / 60 + double.Parse(du);
                    //纬度转换
                    string[] latitudeY = (double.Parse(longitudeLatitude[4]) / 100).ToString().Split('.');
                    string du1 = latitudeY[0];
                    string fen1 = (double.Parse(longitudeLatitude[4]) - double.Parse(du1) * 100).ToString();
                    Longitude = double.Parse(fen1) / 60 + double.Parse(du1);

                    Distance distance = new Distance();

                    distanced = float.Parse(distance.LantitudeLongitudeDist(float.Parse(Longitude.ToString()), float.Parse(Latitude.ToString()), 114.478187, 38.009778).ToString()).ToString();
                    this.label7.Text = Latitude.ToString() + "N";
                    this.label2.Text = Longitude.ToString() + "E";


                    string ccconn = " select * from " + trainNumber;
                    DB db = new DB();
                    DataTable dt = db.reDt(ccconn);
                    int num = dt.Rows.Count;//有多少条数据
                    string stationLongitude = "";
                    string stationLatitude = "";

                    double[] stationsDistance = new double[num];

                    for (int i = 0; i < num; i++)
                    {
                        stationLongitude = dt.Rows[i][2].ToString();
                        stationLatitude = dt.Rows[i][3].ToString();
                        stationsDistance[i] = distance.LantitudeLongitudeDist(float.Parse(stationLongitude), float.Parse(stationLatitude), Longitude, Latitude);//判断当前点与每个车站的距离
                    }

                    double minnum = stationsDistance[0];
                    int minid = 0;
                    for (int n = 0; n < stationsDistance.Length; n++)
                    {
                        if (stationsDistance[n] < minnum)
                        {
                            minnum = stationsDistance[n];
                            minid = n;

                        }
                    }


                    int id = minid + 1;

                    string dataBefore = DateTime.Now.AddMinutes(-1).ToString();  //查找1分钟前数据
                    string dataNow = DateTime.Now.AddSeconds(-10).ToString();//查找10s前数据

                    string sqldataBefore = " select * from Record where 当前时间 = '" + dataBefore + "'";
                    string sqldataNow = " select * from Record where 当前时间 = '" + dataNow + "'";


                    DataTable dtStationDataBefore = db.reDt(sqldataBefore);
                    DataTable dtStationDataNow = db.reDt(sqldataNow);


                    if (dtStationDataBefore.Rows.Count > 0 && dtStationDataNow.Rows.Count > 0)//判断前方到站，并显示
                    {
                        string nearStationDistanceBefore = dtStationDataBefore.Rows[0][5].ToString();//1分钟前 最近站距离
                        string previousStationDistanceBefore = dtStationDataBefore.Rows[0][7].ToString();//1分钟前 前一站距离
                        string latterStationDistanceBefore = dtStationDataBefore.Rows[0][9].ToString();//1分钟前 后一站距离


                        string nearStationDistanceNow = dtStationDataNow.Rows[0][5].ToString();//10s前 最近站距离
                        string previousStationDistanceNow = dtStationDataNow.Rows[0][7].ToString();//10s前 前一站距离
                        string latterStationDistanceNow = dtStationDataNow.Rows[0][9].ToString();//10s前 后一站距离

                       
                        



                        if (float.Parse(nearStationDistanceBefore) >= float.Parse(nearStationDistanceNow)) //判断前方到站 离最近站近了
                        {
                            //最近站为下一站
                            this.label8.Text = dtStationDataBefore.Rows[0][4].ToString();//前方到站名称
                            this.label11.Text = dtStationDataNow.Rows[0][5].ToString();//到站距离
                            
                            
                            string broadcastDistance = "select * from " + trainNumber +" where 站名 = '"+ dtStationDataBefore.Rows[0][4].ToString() + "'" ;
                                                

                            DataTable dtBroadcastdistance = db.reDt(broadcastDistance);
                            float juli= 5;
                            if (dtBroadcastdistance.Rows.Count >0)
                            {
                                juli = float.Parse( dtBroadcastdistance.Rows[0][4].ToString());
                                this.label22.Text = dtBroadcastdistance.Rows[0][4].ToString();
                                

                            }

                            if (float.Parse(nearStationDistanceNow) < juli && float.Parse(nearStationDistanceNow) > 1 && beyondDistance == true && float.Parse(speednow) > 0)//到达报站距离
                            {
                                beforeArrive();//执行5分钟报站
                                beyondDistance = false;//判断条件变为false
                                withinDistance = true;//准备好到站 报站

                            }
                            else if (float.Parse(dtStationDataNow.Rows[0][5].ToString()) <= 1 && withinDistance == true && float.Parse(speednow) > 0)
                            {
                                nowArrive();//执行到站报站
                                withinDistance = false;//判断条件变为false
                            }
                            else if (float.Parse(nearStationDistanceNow) > 5 && float.Parse(speednow) > 0)
                            {
                                outDistance = true;
                                withinDistance = true;
                                beyondDistance = true;
                            }


                            if (speednow != "" && float.Parse(speednow) > 0)
                            {

                                this.label15.Text = (float.Parse(dtStationDataNow.Rows[0][5].ToString()) / float.Parse(speednow)).ToString() + "H";//剩余时间
                            }



                        }
                        else  //离最近站 远了
                        {

                            this.label8.Text = dtStationDataBefore.Rows[0][8].ToString();//前方到站名称
                            this.label11.Text = dtStationDataNow.Rows[0][9].ToString();//到站距离
                                                                            //后一站为下一站
                            this.textBox2.Text =  "前方到站是"+this.label8.Text +"请做好车票查验工作";

                            

                            if (float.Parse(nearStationDistanceNow) > 1 && float.Parse(nearStationDistanceNow) < 5 && outDistance == true && float.Parse(speednow)>0)// 离站报站
                            {
                                nowLeave(dtStationDataNow.Rows[0][8].ToString());//

                                outDistance = false;
                                withinDistance = true;


                            }
                            else if (float.Parse(nearStationDistanceNow) > 5 && float.Parse(speednow) > 0)
                            {
                                outDistance = true;
                                withinDistance = true;
                                beyondDistance = true;
                            }
                            else if (float.Parse(dtStationDataNow.Rows[0][5].ToString()) <= 1 && withinDistance == true && float.Parse(speednow) > 0)
                            {
                                nowArrive();//执行到站报站
                                withinDistance = false;//判断条件变为false
                            }

                            if (speednow != "" && float.Parse(speednow) > 0)
                            {
                                this.label15.Text = (float.Parse(dtStationDataNow.Rows[0][5].ToString()) / float.Parse(speednow)).ToString() + "H";//剩余时间
                            }
                        }


                    }

                    
                    
                    if ((num - 1) >= id && (minid - 1) >= 0)//前后站都有
                    {
                        string selectPreviousStation = "select * from " + trainNumber + " where 编号 =" + (minid) + " ";
                        string selectLatterStation = "select * from " + trainNumber + " where 编号 =" + (minid + 2) + "";
                        DataTable dtPreviousStation = db.reDt(selectPreviousStation);
                        DataTable dtLatterStation = db.reDt(selectLatterStation);
                        if (dtLatterStation.Columns.Count > 1 && dtPreviousStation.Columns.Count > 1)
                        {
                            string previousStationLongitude = dtPreviousStation.Rows[0][2].ToString();
                            string previousStationLatitude = dtPreviousStation.Rows[0][3].ToString();
                            string hzjd = dtLatterStation.Rows[0][2].ToString();
                            string hzwd = dtLatterStation.Rows[0][3].ToString();
                            var latterStationDistance = distance.LantitudeLongitudeDist(float.Parse(hzjd), float.Parse(hzwd), Longitude, Latitude);
                            var previousStationDistance = distance.LantitudeLongitudeDist(float.Parse(previousStationLongitude), float.Parse(previousStationLatitude), Longitude, Latitude);
                            string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,前一站,前一站距离,后一站,后一站距离,当前时间) values" +
                                "('" + Longitude.ToString() + "' ,'" + Latitude.ToString() + "','" + speednow + "','"
                                + dt.Rows[minid][1].ToString() + "','" + stationsDistance[minid].ToString() + "','" + dt.Rows[minid - 1][1].ToString() + "','"
                                + previousStationDistance.ToString() + "','" + dt.Rows[minid + 1][1].ToString() + "','" + latterStationDistance.ToString() + "','" + DateTime.Now.ToString() + "')";
                            db.sqlEx(log);
                        }

                    }
                    else if ((num - 1) >= id && (minid - 1) < 0)//无前一站
                    {

                        //string selectLatterStation = "select 经度 and 纬度 from '" + trainNumber + "' where 编号 =" + (minid + 1) + "";
                        string selectLatterStation = "select * from " + trainNumber + " where 编号 =" + (minid + 2) + "";

                        DataTable dtLatterStation = db.reDt(selectLatterStation);


                        if (dtLatterStation.Columns.Count > 1)
                        {
                            string hzjd = dtLatterStation.Rows[0][2].ToString();
                            string hzwd = dtLatterStation.Rows[0][3].ToString();

                            var latterStationDistance = distance.LantitudeLongitudeDist(float.Parse(hzjd), float.Parse(hzwd), Longitude, Latitude);


                            string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,后一站,后一站距离,当前时间)" +
                                " values('" + Longitude.ToString() + "'," +
                                "'" + Latitude.ToString() + "'," +
                                "'" + this.label3.Text.ToString() + "'" +
                                ",'" + dt.Rows[minid][1].ToString() + "'," +
                                "'" + stationsDistance[minid].ToString() + "'," +
                                "'" + dt.Rows[minid + 1][1].ToString() + "'," +
                                "'" + latterStationDistance.ToString() + "'," +
                                "'" + DateTime.Now.ToString() + "')";
                            db.sqlEx(log);
                        }


                    }



                    else if ((num - 1) < id && (minid - 1) >= 0)//无后一站
                    {
                        string selectPreviousStation = "select * from " + trainNumber + " where 编号 =" + (minid) + " ";
                        DataTable dtPreviousStation = db.reDt(selectPreviousStation);
                        if (dtPreviousStation.Columns.Count > 1)
                        {
                            string previousStationLongitude = dtPreviousStation.Rows[0][2].ToString();
                            string previousStationLatitude = dtPreviousStation.Rows[0][3].ToString();
                            var previousStationDistance = distance.LantitudeLongitudeDist(float.Parse(previousStationLongitude), float.Parse(previousStationLatitude), Longitude, Latitude);
                            string log = " insert into Record (经度,纬度,速度,最近站,最近站距离,前一站,前一站距离,当前时间)" +
                                " values('" + Longitude.ToString() + "'," +
                                "'" + Latitude.ToString() + "'," +
                                "'" + this.label3.Text.ToString() + "'" +
                                ",'" + dt.Rows[minid][1].ToString() + "'," +
                                "'" + stationsDistance[minid].ToString() + "'," +
                                "'" + dt.Rows[minid - 1][1].ToString() + "'," +
                                "'" + previousStationDistance.ToString() + "'," +
                                "'" + DateTime.Now.ToString() + "')";
                            db.sqlEx(log);
                        }
                    }
                }
            } catch (Exception ex) { ex.ToString(); }
             



        }
        public string GetLongitude()
        {
            //供页面调用以传递数据
            return Longitude.ToString();
        }
        public string GetLatitude()
        {
            //供页面调用以传递数据
            return Latitude.ToString();
        }

        string speednow = "";
        private void serialPort2_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try {
                outdata = serialPort2.ReadExisting();
                string[] spkm = outdata.Split(',');
                if (spkm.Length > 7)
                {
                    speednow = spkm[7].ToString();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            


        }
        
        

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

       

        /// <summary>
        /// 选择车次
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (this.comboBox1.Text != "")
                {
                    this.comboBox1.Enabled = false;
                    trainNumber = this.comboBox1.Text;
                }
                else
                {
                    MessageBox.Show("请先选择车次！");
                }
            }
            catch (Exception ex) { ex.ToString(); }
            
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.comboBox1.Enabled = true;
            this.comboBox1.Text = "";
            
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 播报时间区间
        /// </summary>
        bool timetob = false;
        public bool TimeToBro()
        {
            string timenow = DateTime.Now.ToShortTimeString();
            timenow =  timenow.Replace(":","");
            if ( (float.Parse(timenow)>700 && float.Parse(timenow)<1230)||(float.Parse(timenow) > 1500 && float.Parse(timenow) < 2130))
            {
                timetob = true;
                            }
            return timetob;
            
        }
        /// <summary>
        /// 向电台串口传字符
        /// </summary>
        /// <param name="datain"></param>
        public void interPhoneBrodcast(string datain)
        {
            if (serialPort3.IsOpen)
            {
                serialPort3.Write(datain);
            }



        }
        /// <summary>
        /// 自动报站
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        public void beforeArrive()
        {
            try
            {
                if (this.label8.Text != "--" && soundCard == true && TimeToBro())//声卡播报，并且内容不为空，并且在播报时间段内；
                {
                    string path1 = ".\\sound\\中途到站前5分钟通报1.wav";
                    string path2 = ".\\sound\\中途到战前5分钟通报2.wav";
                    string path3 = ".\\sound\\中途到战前5分钟通报3.wav";

                    string path4 = ".\\sound\\" + label8.Text.ToString() + ".wav";

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//站名
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();
                    System.Media.SoundPlayer player5 = new System.Media.SoundPlayer(path4);//站名
                    player5.PlaySync();
                    System.Media.SoundPlayer player3 = new System.Media.SoundPlayer(path3);
                    player3.PlaySync();

                }
                if (this.label8.Text != "--" && interPhone)//电台播报
                {
                    string s = this.label18.Text;
                    string oledstring = "select * from " + trainNumber + " where 站名 = '" + s + "'";

                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][5].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;
                        
                    }
                    olddt = null;


                }
            }
            catch (Exception ex) { ex.ToString(); }
            
            
        }
        public void nowArrive()
        {
            try
            {
                if (this.label8.Text != "--" && soundCard == true && TimeToBro())//声卡播报，并且内容不为空，并且在播报时间段内；
                {
                    string path1 = ".\\sound\\中途到站时确报1.wav";
                    string path2 = ".\\sound\\中途到站时确报2.wav";
                    

                    string path4 = ".\\sound\\" + label8.Text.ToString() + ".wav";

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//站名
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();
                    

                }
                if (this.label8.Text != "--" && interPhone)
                {

                    string s = this.label18.Text;
                    string oledstring = "select * from " + trainNumber + " where 站名 = '" + s + "'";

                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][6].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;

                    }
                    olddt = null;

                }
            }
            catch (Exception ex) { ex.ToString(); }


        }
        /// <summary>
        /// 离站自动播报
        /// </summary>
        /// <param name="xz"></param>
        public void nowLeave( string xz)
        {
            try
            {
                if (this.label8.Text != "--" && soundCard == true && TimeToBro())//声卡播报，并且内容不为空，并且在播报时间段内；
                {
                    string path1 = ".\\sound\\中途开车后预报1.wav";
                    string path2 = ".\\sound\\中途开车后预报2.wav";
                    string path3 = ".\\sound\\中途开车后预报3.wav";

                    string path4 = ".\\sound\\" + this.comboBox1.Text+ ".wav";//车次名称
                    string path5 = ".\\sound\\" + xz + ".wav";//下一站名称

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//车次名称
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();
                    System.Media.SoundPlayer player5 = new System.Media.SoundPlayer(path4);//下一站名称
                    player5.PlaySync();
                    System.Media.SoundPlayer player3 = new System.Media.SoundPlayer(path3);
                    player3.PlaySync();

                }
                if (this.label8.Text != "--" && interPhone)
                {

                    string s = this.label18.Text;
                    string oledstring = "select * from " + trainNumber + " where 站名 = '" + xz + "'";

                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][7].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;

                    }
                    olddt = null;

                }

            }
            catch (Exception ex) { ex.ToString(); }


        }

        bool soundCardManual= false;
        bool interPhoneManual = false;
        /// <summary>
        /// 手动报站
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            if (this.comboBox2.Text != "" && this.comboBox3.Text != "" && this.comboBox4.Text != "" && this.comboBox7.Text != "" )
            {   
                //选择声卡还是电台播报
                if (this.comboBox7.Text == "声卡报站")
                {
                    soundCardManual = true;
                    interPhoneManual = false;


                }
                else if (this.comboBox7.Text == "电台报站")
                {
                    if (!serialPort3.IsOpen)
                    {
                        MessageBox.Show("请先前往“手动报站打开电台串口”");
                        return ;
                    }
                    interPhoneManual = true;
                    soundCardManual = false;


                }
                else if (this.comboBox7.Text == "声卡、电台同时报站")
                {
                    if (!serialPort3.IsOpen)
                    {
                        MessageBox.Show("请先前往“手动报站打开电台串口”");
                        return ;
                    }
                    soundCardManual = true;
                    interPhoneManual = true;
                }
                
                //选择报站类型
                if (this.comboBox3.Text == "中途到站前5分钟通报")
                {
                    beforeA();
                }
                else if (this.comboBox3.Text == "中途到站时确报")
                {
                    nowA();
                }
                else if (this.comboBox3.Text == "中途开车后预报")
                {
                    //int n= int.Parse( this.comboBox4.SelectedValue.ToString());
                    string m = this.comboBox4.Text;  //comboBox4.GetItemText(this.comboBox4.Items[n]);
                    nowL(m);
                }


            }
            else
            { MessageBox.Show("请选择好上述各项！"); }
        }

        /// <summary>
        /// 手动报站确认车次
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click_1(object sender, EventArgs e)
        {
            if (this.comboBox2.Enabled == true)
            {
                trainNumber = this.comboBox2.Text;
                
                this.comboBox2.Enabled = false;
                this.button5.Text = "重置";
                DB db1 = new DB();
                string oledb = "select 编号,站名 from "+this.comboBox2.Text+"" ;
                this.comboBox4.DisplayMember = "站名";
                this.comboBox4.ValueMember = "编号";
                this.comboBox4.DataSource = db1.reDt(oledb);
                


            }
            else if (this.comboBox2.Enabled == false)
            {
                this.comboBox2.Enabled = true;
            
                this.button5.Text = "确认";
                this.trainNumber = "";
                interPhoneManual = false;
                soundCardManual = false;
            }

        }
        /// <summary>
        /// 到战前5分钟报站
        /// </summary>
        public void beforeA()
        {
            try
            {
                if (this.comboBox4.Text != "--" && interPhoneManual) //电台报站
                {
                    string s = this.comboBox4.Text;
                    string oledstring = "select * from " + trainNumber + " where 站名 = '" + s + "'";

                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][5].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;


                    }
                }
                if (this.comboBox4.Text != "--" && soundCardManual)
                {
                    string path1 = ".\\sound\\中途到站前5分钟通报1.wav";
                    string path2 = ".\\sound\\中途到战前5分钟通报2.wav";
                    string path3 = ".\\sound\\中途到战前5分钟通报3.wav";

                    string path4 = ".\\sound\\" + this.comboBox4.Text + ".wav";

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//站名
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();
                    System.Media.SoundPlayer player5 = new System.Media.SoundPlayer(path4);//站名
                    player5.PlaySync();
                    System.Media.SoundPlayer player3 = new System.Media.SoundPlayer(path3);
                    player3.PlaySync();

                }

                
                }
            catch (Exception ex) { ex.ToString(); }


        }
        /// <summary>
        /// 到站报站
        /// </summary>
        public void nowA()
        {
            try
            {
                if (this.comboBox4.Text != "--" && interPhoneManual) //电台报站
                {
                    string s = this.comboBox4.Text;
                    string oledstring = " select * from " + trainNumber + " where 站名 = '" + s + "'";
                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][6].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;


                    }
                }
                if (this.comboBox4.Text != "--" && soundCardManual)
                {
                    string path1 = ".\\sound\\中途到站时确报1.wav";
                    string path2 = ".\\sound\\中途到站时确报2.wav";
                    string path4 = ".\\sound\\" + this.comboBox4.Text  + ".wav";

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//站名
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();


                }
                
            }
            catch (Exception ex) { ex.ToString(); }


        }
        /// <summary>
        /// 离站手动报站
        /// </summary>
        /// <param name="xz"></param>
        public void nowL(string xz)
        {
            try
            {
                if (this.comboBox4.Text != "--" && interPhoneManual) //电台报站
                {
                    string s = this.comboBox4.Text;
                    string oledstring = " select * from " + trainNumber + " where 站名 = '" + s + "'";
                    DB oldb = new DB();
                    DataTable olddt = oldb.reDt(oledstring);
                    if (olddt.Rows.Count > 0)
                    {
                        string st = olddt.Rows[0][7].ToString();
                        interPhoneBrodcast(st);
                        this.textBox2.Text = st;


                    }
                }
                if (this.comboBox4.Text != "--" && soundCardManual)
                {
                    string path1 = ".\\sound\\中途开车后预报1.wav";
                    string path2 = ".\\sound\\中途开车后预报2.wav";
                    string path3 = ".\\sound\\中途开车后预报3.wav";

                    string path4 = ".\\sound\\" + this.comboBox2.Text + ".wav";//车次名称
                    string path5 = ".\\sound\\" + xz + ".wav";//下一站名称

                    System.Media.SoundPlayer player1 = new System.Media.SoundPlayer(path1);
                    player1.PlaySync();
                    System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(path4);//车次名称
                    player4.PlaySync();
                    System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(path2);
                    player2.PlaySync();
                    System.Media.SoundPlayer player5 = new System.Media.SoundPlayer(path4);//下一站名称
                    player5.PlaySync();
                    System.Media.SoundPlayer player3 = new System.Media.SoundPlayer(path3);
                    player3.PlaySync();

                }
                
            }
            catch (Exception ex) { ex.ToString(); }


        }

        /// <summary>
        /// 数据采集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                DB cj = new DB();

                string log = " insert into caiji (经度,纬度,当前时间)" +
                                    " values('" + Longitude.ToString() + "'," +
                                    "'" + Latitude.ToString() + "'," +

                                    "'" + DateTime.Now.ToString() + "')";
                cj.sqlEx(log);
                this.label20.Text = DateTime.Now.ToString() + "数据采集成功！";
            }
            catch (Exception ex) { ex.ToString(); }               
            

        }


        bool interPhone = false;
        bool soundCard = false;

        /// <summary>
        /// 报站方式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            this.comboBox5.Enabled = false;

            if (this.comboBox5.Text == "声卡报站")
            {
                soundCard = true;
                interPhone = false;


            }
            else if (this.comboBox5.Text == "电台报站")
            {
                if (!serialPort3.IsOpen)
                {
                    MessageBox.Show("请先前往“手动报站打开电台串口”");
                }
                interPhone = true;
                soundCard = false;


            }
            else if (this.comboBox5.Text == "声卡、电台同时报站")
            {
                if (!serialPort3.IsOpen)
                {
                    MessageBox.Show("请先前往“手动报站打开电台串口”");
                }
                soundCard = true;
                interPhone = true;
            }

        }
        /// <summary>
        /// 重置报站方式
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            this.comboBox5.Enabled = true;
            soundCard = false;
            interPhone = false;

        }

        /// <summary>
        /// 打开电台串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                if (!serialPort3.IsOpen)
                {
                    this.serialPort3.DataBits = 8;
                    this.serialPort3.BaudRate = 9600;
                    this.serialPort3.PortName = this.comboBox6.Text;
                    this.serialPort3.StopBits = System.IO.Ports.StopBits.One;
                    this.serialPort3.Parity = System.IO.Ports.Parity.None;
                    this.serialPort3.Encoding = System.Text.Encoding.UTF8;
                    serialPort3.Open();
                }
            }
            catch (Exception ex) { ex.ToString(); }
        }

        /// <summary>
        /// 关闭电台串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button12_Click(object sender, EventArgs e)
        {
            if (serialPort3.IsOpen)
            {
                serialPort3.Close();
            }
        }

        /// <summary>
        /// 手动播报text 内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                string interphoneContent = string.Empty;
                interphoneContent = this.textBox2.Text;
                serialPort3.Write(interphoneContent);
            }
            catch (Exception ex) { ex.ToString(); }
        }


        string stationName = string.Empty;//站名
        string id = string.Empty;//编号
        string rowHeader = string.Empty;//列名
        /// <summary>
        /// 确认要修改的车次
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button13_Click(object sender, EventArgs e)
        {

            if (this.comboBox8.Enabled == true)
            {
                stationName = this.comboBox8.Text;
                this.comboBox8.Enabled = false;
                this.button13.Text = "重置";
                DB db1 = new DB();
                string oledb = "select 编号,站名,报站距离,到站前作业,到站作业,发车作业  from  " + this.comboBox8.Text + "";
                
                this.dataGridView1.DataSource = db1.reDt(oledb);



            }
            else if (this.comboBox8.Enabled == false)
            {
                this.comboBox8.Enabled = true;
                this.button13.Text = "确认";
                this.dataGridView1.DataSource = null;
                
            }
        }

        

       
        /// <summary>
        /// 提交修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                DB db2 = new DB();
                string oledb1 = "update " + stationName + "  set  " + rowHeader + " ='" + this.textBox3.Text + "' where 编号 = " + id + " ";
                db2.sqlEx(oledb1);
                MessageBox.Show("修改成功");

                string oledb2 = "select 编号,站名,报站距离,到站前作业,到站作业,发车作业  from  " + this.comboBox8.Text + "";

                this.dataGridView1.DataSource = db2.reDt(oledb2);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            
            


        }

       
        /// <summary>
        /// 单击表格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.textBox3.Text = this.dataGridView1.CurrentCell.Value.ToString();
                //this.textBox3.Text = this.dataGridView1.SelectedCells[0].Value.ToString();
                rowHeader = dataGridView1.Columns[e.ColumnIndex].HeaderText;//获取标题
                id = this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();//获取编号

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
