﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.IO;
using System.Threading;

namespace bdapi
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class Form1 : Form
    {
        
        string indata;
        public static float Longitude = 38 ;//经度
        public static float Latitude = 114; //纬度
        

        //百度api
        private static string url = @"http://api.map.baidu.com/geocoder/v2/?location={0}&output=json&ak=aIlFdLnHIUwsnvFVoGrFWWA1YPIUqg3T";

        /// <summary>
        /// 根据经纬度获取地理位置
        /// </summary>
        /// <param name="lat">纬度</param>
        /// <param name="lng">经度</param>
        /// <returns>具体的地埋位置</returns>
        public static string GetLocation(string lat, string lng)
        {
            HttpClient client = new HttpClient();
            string location = string.Format("{0},{1}", lat, lng);
            string bdUrl = string.Format(url, location);
            string result = client.GetStringAsync(bdUrl).Result;
            var locationResult = (JObject)JsonConvert.DeserializeObject(result);

            if (locationResult == null || locationResult["result"] == null || locationResult["result"]["formatted_address"] == null)
                return string.Empty;

            var address = Convert.ToString(locationResult["result"]["formatted_address"]);
            if (locationResult["result"]["sematic_description"] != null)
                address += " " + Convert.ToString(locationResult["result"]["sematic_description"]);
            return address;
        }
        public Form1()
        {
            InitializeComponent();

            webBrowser1.ScriptErrorsSuppressed = true;
            string path = Path.Combine(Application.StartupPath, "HTMLPage1.html");
            webBrowser1.Navigate(path);
            webBrowser1.ObjectForScripting = this;//设置对象为当前BusinessDataExportFigure窗体


        }
        
        
        
        
        private void Form1_Load(object sender, EventArgs e)
        {
           // Thread thread1 = new Thread( new ThreadStart());
            
           // Thread thread2 = new Thread( new ThreadStart());
            
            this.serialPort1.DataBits = 8;
            this.serialPort1.BaudRate = 9600;
            this.serialPort1.PortName = "COM4";
            this.serialPort1.StopBits = System.IO.Ports.StopBits.One;
            this.serialPort1.Parity = System.IO.Ports.Parity.None;
            this.serialPort1.Encoding = System.Text.Encoding.UTF8;

            serialPort1.Open();

            if (this.serialPort2.IsOpen)
            {
                this.label9.Text = "端口已打开";
            }
            else
            {
                this.label9.Text = "端口已关闭";

            }

        }

        /// <summary>
        /// 启动gps
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.serialPort2.DataBits = 8;
                this.serialPort2.BaudRate = 9600;
                this.serialPort2.PortName = "COM5";
                this.serialPort2.StopBits = System.IO.Ports.StopBits.One;
                this.serialPort2.Parity = System.IO.Ports.Parity.None;
                this.serialPort2.Encoding = System.Text.Encoding.UTF8;
                serialPort2.Open();
               


                string outdata1 = "AT+QGPSCFG='gpsnmeatype',2\r\n";
                string outdata2 = "AT+QGPSCFG='nmeasrc',1\r\n";
                string outdata3 = "AT+QGPS=1\r\n";

                serialPort2.Write(outdata1);//把字符串写入端口
                serialPort2.Write(outdata2);
                serialPort2.Write(outdata3);

                if (this.serialPort2.IsOpen)
                {
                    this.label9.Text = "端口已打开";
                }
                else
                {
                    this.label9.Text = "端口已关闭";

                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.ToString()); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string outdata4 = "AT+QGPSEND \r\n";

                serialPort2.Write(outdata4);

                this.label1.Text = "无数据";
                this.label7.Text = "无数据";
                this.label2.Text = "无数据";
                this.label3.Text = "无数据";
                this.serialPort2.Close();

                if (this.serialPort2.IsOpen)
                {
                    this.label9.Text = "端口已打开";
                }
                else
                {
                    this.label9.Text = "端口已关闭";

                }
            }
            catch (Exception ex) { ex.ToString(); }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.serialPort1.IsOpen)
            {
                this.serialPort1.Close();
            }

            if (this.serialPort2.IsOpen)
            {
                string outdata4 = "AT+QGPSEND \r\n";

                serialPort2.Write(outdata4);

                this.label1.Text = "无数据";
                this.label7.Text = "无数据";
                this.label2.Text = "无数据";
                this.label3.Text = "无数据";

                this.serialPort2.Close();
            }

        }

       
        
        
        /// <summary>
        /// 接受到数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            

            try
            {
                

                indata = serialPort1.ReadExisting();
                this.Invoke(new EventHandler(DisplayText));
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
            

        }
        
        private void DisplayText(object sender, EventArgs e)
        {
            string[] jwds = indata.Split(',');
            


            if (jwds[0] == "$GPRMC"&& jwds[3] != "")

               
            {

                
                this.label1.Text = GetLocation((float.Parse(jwds[3])/100).ToString(), (float.Parse(jwds[5])/100).ToString());

                this.label7.Text = (float.Parse(jwds[3]) / 100).ToString();
                Longitude = float.Parse(jwds[3]) / 100;
                //(Longitude).ToString();

                this.label2.Text = (float.Parse(jwds[5]) / 100).ToString();
                Latitude = float.Parse(jwds[5]) / 100;
                //(Latitude).ToString() ;
                this.label3.Text = jwds[7];

                
            }



        }
        public string GetLongitude()
        {
            
            //供页面调用以传递数据
            return Longitude.ToString();
        }
        public string GetLatitude()
        {
            
            //供页面调用以传递数据
            return Latitude.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.webBrowser1.Refresh();
        }
    }
}
